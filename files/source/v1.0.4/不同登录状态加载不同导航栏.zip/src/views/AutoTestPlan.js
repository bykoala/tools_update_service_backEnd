import React from 'react'

function AutoTestPlan() {
    return (
        <div>
            <h1>功能模块待规划...敬请期待</h1>
        </div>
    )
}

export default AutoTestPlan
