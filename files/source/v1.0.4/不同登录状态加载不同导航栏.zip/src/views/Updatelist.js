import React from 'react'

import Frame from "../components/Frame/Index"
// import NavLine from "../components/Nav/NavLine";

function updatelist() {
    return (
      //   <Frame>
      //   {/* <NavLine></NavLine> */}
      // </Frame>
        <h1>我是更新历史页</h1>
    )
}

export default updatelist
