import React from 'react'

function contactMe() {
    return (
        <div>
            <h1>联系我</h1>
        </div>
    )
}

export default contactMe
